;/*FB_PKG_DELIM*/

__d("LSTruncateQuietTime",[],(function(t,n,r,o,a,i){function e(){var e=arguments,t=e[e.length-1],n=[],r=[];return t.sequence([function(e){return t.forEach(t.db.table(317).fetch(),function(e){return e.delete()})},function(e){return t.resolve(r)}])}e.__sproc_name__="LSOmnistoreSettingsTruncateQuietTimeStoredProcedure",e.__tables__=["msgr_quiet_time"],a.exports=e}),null);